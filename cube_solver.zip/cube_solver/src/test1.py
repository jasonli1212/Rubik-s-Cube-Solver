def a():
    return "a"