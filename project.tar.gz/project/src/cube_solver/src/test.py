#!/usr/bin/env python
import kociemba
import test1
if __name__ == '__main__':
    print(test1.a())
    print('hello')